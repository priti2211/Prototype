<?php
	echo $_POST['email']
	echo $_POST['username']
	if(isset($_POST['userpass1'] === $_POST['userpass2'])){
		userpass== $_POST['userpass1']
		echo userpass
	}
	else{
		echo "re-enter Password"
	}
?>